<!DOCTYPE>
<html>
    <head></head>

    <body>

        <p>Name : {{ $name }}</p>
        <p>Email : {{ $email  }}</p>
        <p>Phone : {{ $phone  }}</p>
        <p>Subject : {{ $subject  }}</p>
        <p>Message:<br>{{ $msg  }}</p>

        <br><br>

    </body>
</html>