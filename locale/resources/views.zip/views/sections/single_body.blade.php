@extends('layouts.master')

@section('content')
    <section class="row page_intro">
        <div class="row m0 inner" style="background: url('{{ asset('public/uploads/large/' . $body->media->guid) }}') !important;">
            <div class="container">
                <div class="row">
                    <h4 style="color: white !important;">
                        {{trans('main.face')}}
                    </h4>
                    <h2>{{$face->post_title}}</h2>
                </div>
            </div>
        </div>
    </section>
    <section class="row breadcrumbRow">
        <div class="container">
            <div class="row inner m0">
                <ul class="breadcrumb">
                    <li><a href="{{route('frontend.home.get')}}">Home</a></li>
                    <li class="dropdown">
                        <a href="{{route('frontend.body.get')}}" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            {{trans('main.body')}}
                        </a>

                    </li>
                    <li>{{$body->post_title}}</li>
                </ul>
            </div>
        </div>
    </section>

    <section class="row service_details">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 serviceDetailsSection">
                    <h2 class="post_title">
                        <span class="post_icon"><img src="{{ asset('public/uploads/large/' . $body->media->guid) }}" alt=""></span>
                        <br>
                        {{$body->post_title}}</h2>
                    <table class="table table-striped table-bordered">
                        <tbody>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.indication')}} </h4>
                            </td>
                            <td>
                                {{$body->post_indication}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.definition')}} </h4>
                            </td>
                            <td>
                                {{$body->post_definition}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.ot')}} </h4>
                            </td>
                            <td>
                                {{$body->post_operative_time}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.anesthesia')}} </h4>
                            </td>
                            <td>
                                {{$body->post_anesthesia}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.hs')}} </h4>
                            </td>
                            <td>
                                {{$body->post_hs}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.scars')}} </h4>
                            </td>
                            <td>
                                {{$body->post_scars}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.ln')}} </h4>
                            </td>
                            <td>

                                {{$body->post_labs_needed}}


                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.convalescence')}} </h4>
                            </td>
                            <td>
                                {{$body->post_convalescence}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.fr')}} </h4>
                            </td>
                            <td>
                                {{$body->post_final_result}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.nb')}} </h4>
                            </td>
                            <td>

                                {{$body->post_nb}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.price')}} </h4>
                            </td>
                            <td>

                                {{$body->post_price}}
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>

    @include('partials.question')

@stop