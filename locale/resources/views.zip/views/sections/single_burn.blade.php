@extends('layouts.master')

@section('content')
    <section class="row page_intro">
        <div class="row m0 inner" style="background: url('{{ asset('public/uploads/large/' . $burn->media->guid) }}') !important;">
            <div class="container">
                <div class="row">
                    <h4 style="color: white !important;">
                        {{trans('main.face')}}
                    </h4>
                    <h2>{{$face->post_title}}</h2>
                </div>
            </div>
        </div>
    </section>
    <section class="row breadcrumbRow">
        <div class="container">
            <div class="row inner m0">
                <ul class="breadcrumb">
                    <li><a href="{{route('frontend.home.get')}}">{{trans('main.home')}}</a></li>
                    <li class="dropdown">
                        <a href="{{route('frontend.burn.get')}}" class="dropdown-toggle" data-toggle="" role="button" aria-expanded="false">
                            {{trans('main.burn')}}
                        </a>

                    </li>
                    <li>{{$face->post_title}}</li>
                </ul>
            </div>
        </div>
    </section>
    <section class="row breadcrumbRow">
        <div class="container">
            <div class="row inner m0">
                <ul class="breadcrumb">
                    <li><a href="{{route('frontend.home.get')}}">{{trans('main.home')}}</a></li>
                    <li class="dropdown">
                        <a href="{{route('frontend.burn.get')}}" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                           {{trans('main.burn')}}
                        </a>

                    </li>
                    <li>{{$burn->post_title}}</li>
                </ul>
            </div>
        </div>
    </section>

    <section class="row service_details">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 serviceDetailsSection">
                    <h2 class="post_title">
                        <span class="post_icon"><img src="{{ asset('public/uploads/large/' . $burn->media->guid) }}" alt=""></span>
                        <br>
                        {{$burn->post_title}}</h2>
                    <table class="table table-striped table-bordered">
                        <tbody>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.indication')}} </h4>
                            </td>
                            <td>
                                {{$burn->post_indication}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.definition')}} </h4>
                            </td>
                            <td>
                                {{$burn->post_definition}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.ot')}} </h4>
                            </td>
                            <td>
                                {{$burn->post_operative_time}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.anesthesia')}} </h4>
                            </td>
                            <td>
                                {{$burn->post_anesthesia}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.hs')}} </h4>
                            </td>
                            <td>
                                {{$burn->post_hs}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.scars')}} </h4>
                            </td>
                            <td>
                                {{$burn->post_scars}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.ln')}} </h4>
                            </td>
                            <td>

                                {{$burn->post_labs_needed}}


                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.convalescence')}} </h4>
                            </td>
                            <td>
                                {{$burn->post_convalescence}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.fr')}} </h4>
                            </td>
                            <td>
                                {{$burn->post_final_result}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.nb')}} </h4>
                            </td>
                            <td>

                                {{$burn->post_nb}}
                            </td>
                        </tr>
                        <tr>
                            <td class="headcolor">
                                <h4> {{trans('main.price')}} </h4>
                            </td>
                            <td>

                                {{$burn->post_price}}
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>

    @include('partials.question')

@stop