
@extends('layouts.master')


@section('content')


    <div class="carousel fade-carousel slide" data-ride="carousel" data-interval="4000" id="bs-carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#bs-carousel" data-slide-to="0" class="active"></li>
            <li data-target="#bs-carousel" data-slide-to="1"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner">
            <div class="item slides active">
                <div class="slide-1"></div>
                <div class="hero">
                    <hgroup>
                        <h1>{{trans('main.clinic')}}</h1>
                        <h3> YOUR PERFECT PLASTIC MEDICAL SERVICES </h3>
                    </hgroup>
                    <br />
                    <img class="call" />
                </div>
            </div>
            <div class="item slides">
                <div class="slide-2 "></div>
                <div class="hero">
                    <hgroup>
                        <h1>{{trans('main.clinic')}}</h1>
                        <h3> YOUR PERFECT PLASTIC MEDICAL SERVICES </h3>
                    </hgroup>
                    <br />
                    <img class="call" />
                </div>
            </div>

        </div>
    </div>

    <section class="row service_block_row" id="services">
        <div class="container">
            <div class="row titleRow">
                <h5> </h5>
                <h2 style="color:#FFF"> {{trans('main.cs')}}</h2>
            </div>
            <div class="row text-center">
                <span>the best of you</span>
                <div class="col-sm-6 col-md-3">
                    <!-- Service One -->
                    <div class="service-output service-1">
                        <a href="{{route('frontend.face.get')}}"><img src="{{asset('public/frontend')}}/img/full/face.jpg" alt="service1"></a>
                        <span class="service-title">{{trans('main.fps')}}</span>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <!-- Service Two -->
                    <div class="service-output service-2">
                        <a href="{{route('frontend.body.get')}}"><img src="{{asset('public/frontend')}}/img/full/body.jpg" alt="service2"></a>
                        <span class="service-title">{{trans('main.bps')}} </span>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <!-- Service Three -->
                    <div class="service-output service-3">
                        <a href="{{route('frontend.burn.get')}}"><img src="{{asset('public/frontend')}}/img/full/burn.jpg" alt="service1"></a>
                        <span class="service-title">{{trans('main.bups')}}</span>
                    </div>
                </div>
                <div class="col-sm-6 col-md-3" style=" top: -20px;">
                    <!-- Service Four -->
                    <div class="service-output service-4">
                        <a href="{{route('frontend.breast.get')}}"><img src="{{asset('public/frontend')}}/img/full/breast.jpg" alt="service1"></a>
                        <span class="service-title">{{trans('main.brps')}} </span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- About clinic -->
    <section class="row about_medicalpro_row">
        <div class="container">
            <div class="row titleRow">
                <h2> {{trans('main.ac')}}</h2>
            </div>
            <div class="row m0 about_medicalpro">
                <div class="row m0 inner">
                    <div class="col-sm-12 col-md-6 img">
                        <div class="row">
                            <img src="{{asset('public/frontend')}}/img/full/55be5b97e119c5e924adfd2eda166ae3007251ba.png" alt="" class="img-responsive">
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6 content">
                        <div class="row">
                            <!--<h3></h3>-->
                            <p>
                            {!! $about_home->post_content !!}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- About doctor -->
    <section class="row team_section about_doctor_row">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 col-md-12 team_descss">
                    <div class="row">
                        <div class="tab-content">

                            <div role="tabpanel" class="tab-pane media active" id="doctor1">
                                <div class="media-left media-bottom">
                                    <a href="#"><img src="{{asset('public/frontend')}}/img/full/028fd64bebeb2e1b16e462beef492c98c765e190.png" alt="" class="img-responsive"></a>
                                </div>
                                <div class="media-body">
                                    <div class="row titleRow text-left">
                                        <h2>{{trans('main.name')}}</h2>
                                        <span>{{trans('main.job')}}</span>
                                    </div>
                                    <p><p>
                                        {!! $about_dr->post_content !!}
                                    </p>

                                    <p>&nbsp;</p></p>

                                    <ul class="social_list">
                                        <li><a href="https://www.facebook.com/Kenawyclinic"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="https://eg.linkedin.com/in/ahmed-kenawy-b6439459"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="https://www.instagram.com/dr_ahmedkenawy/"><i class="fa fa-instagram"></i></a></li>
                                    </ul>
                                </div>
                            </div><!-- Doctor about-->

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <div id="highlights">
        <div class="appoint text-center">
            <h4>{{trans('main.callme')}}</h4>
            <span>{{trans('main.callat')}}</span>
            <!-- Phone -->
            <span class="phone">01062616085</span>
        </div>
        <div class="container">
            <div class="row">
                <div class="row titleRow">
                    <h2 style="color: #dbb76e"> BEFORE &amp; AFTER GALLERY </h2>
                </div>
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner" role="listbox">
                        <div class="item next left">
                            <div class="col-sm-6">
                                <!-- Highlight One -->
                                <div class="highlight-output highlight-1">
                                    <img src="http://blueplasticsurgery.com/wp-content/themes/aaa-martinblue/mods/images/specialty/before-after.jpg" alt="before-after">
                                    <span class="highlight-subtitle">{{trans('main.procedure')}}: </span>
                                    <span>{{trans('main.age')}}: 45</span>
                                    <span>{{trans('main.recovery')}}: 2 Weeks</span>
                                    <p>{{trans('main.details')}}.:</p>
                                    <a href="#">{{trans('main.bandag')}}</a>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <!-- Highlight Two -->
                                <div class="highlight-output highlight-2">
                                    <img src="http://blueplasticsurgery.com/wp-content/themes/aaa-martinblue/mods/images/specialty/before-after.jpg" alt="before-after">
                                    <span class="highlight-subtitle">Procedure: Facelift</span>
                                    <span>Age: 45</span>
                                    <span>Recovery: 2 Weeks</span>
                                    <p>Details about what client wanted done and suggested procedure and why.</p>
                                    <a href="#">Before &amp; After Gallery</a>
                                </div>

                            </div>
                        </div>
                        <div class="item active left">
                            <div class="col-sm-6">
                                <!-- Highlight One -->
                                <div class="highlight-output highlight-1">
                                    <img src="http://blueplasticsurgery.com/wp-content/themes/aaa-martinblue/mods/images/specialty/before-after.jpg" alt="before-after">
                                    <span class="highlight-subtitle">Procedure: Facelift</span>
                                    <span>Age: 45</span>
                                    <span>Recovery: 2 Weeks</span>
                                    <p>Details about what client wanted done and suggested procedure and why.</p>
                                    <a href="#">Before &amp; After Gallery</a>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <!-- Highlight Two -->
                                <div class="highlight-output highlight-2">
                                    <img src="http://blueplasticsurgery.com/wp-content/themes/aaa-martinblue/mods/images/specialty/before-after.jpg" alt="before-after">
                                    <span class="highlight-subtitle">Procedure: Facelift</span>
                                    <span>Age: 45</span>
                                    <span>Recovery: 2 Weeks</span>
                                    <p>Details about what client wanted done and suggested procedure and why.</p>
                                    <a href="#">Before &amp; After Gallery</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Left and right controls -->
                    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4106.735368925008!2d31.19054862914926!3d30.055814449895948!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1458414629b8bfd5%3A0x60ffff436695b906!2s190+Sudan%2C+Al+Moatamadeyah%2C+Imbaba%2C+Giza+Governorate!5e0!3m2!1sen!2seg!4v1481202782819" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>

    @stop