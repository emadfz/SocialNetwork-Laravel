@extends('layouts.master')

@section('content')
<section class="row page_intro" style=" height: 230px;">
    <div class="row m0 inner" style=" padding-top: calc(7% - 10px);">
        <div class="container">
            <div class="row">
                <h2>Contact us</h2>
            </div>
        </div>
    </div>
</section>
<section class="row breadcrumbRow">
    <div class="container">
        <div class="row inner m0">
            <ul class="breadcrumb">
                <li><a href="index.html">Home</a></li>
                <li>Contact us</li>
            </ul>
        </div>
    </div>
</section>

<section class="row contact_form_row">
    <div class="container">
        <div class="row">
            <h3 class="contact_section_title" style="padding-left:10px;padding-right:10px;"> Contact</h3>
            <div class="col-md-6">
                <p>Please feel free to contact us by filling out the form found on this page or call us at&nbsp; 0106261608 . Follow us on all of our social medias so that you can keep up with our latest specials!</p>
                <h3 style="color: #b28f53;">Kenawy Plastic Clinic </h3>
                190 Sudan ST - Mohandeseen
                <p>
                    <strong>Phone: </strong> 01001775586 - 01062616085  <br />
                    <strong>Email: </strong> d.ahmedkenawy@yahoo.com
                </p>
                <ul class="social_list">
                    <li><a href="https://www.facebook.com/Kenawyclinic"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="https://eg.linkedin.com/in/ahmed-kenawy-b6439459"><i class="fa fa-linkedin"></i></a></li>
                    <li><a href="https://www.instagram.com/dr_ahmedkenawy/"><i class="fa fa-instagram"></i></a></li>
                </ul>
            </div>
            <div class="col-md-6">
                <h3 style=" margin-top: 0;">Make an Appointment </h3>
                <div class="contactForm m0">
                    <form action="http://8-digitalmarketing.com/demo/kenawy-clinic/en/contact_post" method="POST" id="contactForm">
                        <input type="hidden" name="_token" value="YBNAohsSzITDRV0Br05cxixjJTL8atdM5PongT1P">
                        <div class="form-all">
                            <div class="form-section page-section">
                                <div class="form-group">
                                    <!--<label for="contact_fname">Full Name</label>-->
                                    <input type="text" class="form-control" id="contact_fname" placeholder="Full Name" name="fname" required>
                                </div>
                                <div class="form-group" data-type="control_textbox" id="id_3">
                                    <!--<label for="contact_femail">Phone Number </label>-->
                                    <input type="tel" class="form-control" id="contact_fphone" placeholder="Phone" name="phone" required>
                                </div>
                                <div class="form-group" data-type="control_textbox" id="id_4">
                                    <!--<label for="contact_femail">Your e-mail address</label>-->
                                    <input type="email" class="form-control" id="contact_femail" placeholder="Your E-mail" name="email" required>
                                </div>
                                <div class="form-group" data-type="control_textarea" id="id_5">
                                    <!--<label for="contact_fmsg">Message</label>-->
                                    <textarea name="msg" id="contact_fmsg" class="form-control" placeholder="Your Message" rows="4" required></textarea>
                                </div>
                            </div>
                            <div class="clearfix m0">
                                <div class="col-sm-12">
                                </div>
                            </div>
                            <div class="">
                                <input type="submit" class="submit_btn btn btn-yellow" style="width:100%;border-radius:0;" value="Send">
                            </div>
                        </div>
                    </form>
                    <div id="success">
                            <span class="green textcenter">
                                Your message was sent successfully! I will be in touch as soon as I can.
                            </span>
                    </div>
                    <div id="error">
                            <span>
                                Something went wrong, try refreshing and submitting the form again.
                            </span>
                    </div>
                </div>
            </div>
        </div>
        <br /><br />
        <div class="row">
            <div class="col-md-12">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4106.735368925008!2d31.19054862914926!3d30.055814449895948!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1458414629b8bfd5%3A0x60ffff436695b906!2s190+Sudan%2C+Al+Moatamadeyah%2C+Imbaba%2C+Giza+Governorate!5e0!3m2!1sen!2seg!4v1481202782819" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</section>

<div id="highlights">
    <div class="appoint text-center">
        <h4>Schedule a Consultation today </h4>
        <span>Call our clinic At</span>
        <!-- Phone -->
        <span class="phone">01062616085</span>
    </div>
    <div class="container">
        <div class="row">
            <div class="row titleRow">
                <h2 style="color: #dbb76e"> BEFORE &amp; AFTER GALLERY </h2>
            </div>
            <div id="myCarousel" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner" role="listbox">
                    <div class="item next left">
                        <div class="col-sm-6">
                            <!-- Highlight One -->
                            <div class="highlight-output highlight-1">
                                <img src="http://blueplasticsurgery.com/wp-content/themes/aaa-martinblue/mods/images/specialty/before-after.jpg" alt="before-after">
                                <span class="highlight-subtitle">Procedure: Facelift</span>
                                <span>Age: 45</span>
                                <span>Recovery: 2 Weeks</span>
                                <p>Details about what client wanted done and suggested procedure and why.</p>
                                <a href="#">Before &amp; After Gallery</a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <!-- Highlight Two -->
                            <div class="highlight-output highlight-2">
                                <img src="http://blueplasticsurgery.com/wp-content/themes/aaa-martinblue/mods/images/specialty/before-after.jpg" alt="before-after">
                                <span class="highlight-subtitle">Procedure: Facelift</span>
                                <span>Age: 45</span>
                                <span>Recovery: 2 Weeks</span>
                                <p>Details about what client wanted done and suggested procedure and why.</p>
                                <a href="#">Before &amp; After Gallery</a>
                            </div>

                        </div>
                    </div>
                    <div class="item active left">
                        <div class="col-sm-6">
                            <!-- Highlight One -->
                            <div class="highlight-output highlight-1">
                                <img src="http://blueplasticsurgery.com/wp-content/themes/aaa-martinblue/mods/images/specialty/before-after.jpg" alt="before-after">
                                <span class="highlight-subtitle">Procedure: Facelift</span>
                                <span>Age: 45</span>
                                <span>Recovery: 2 Weeks</span>
                                <p>Details about what client wanted done and suggested procedure and why.</p>
                                <a href="#">Before &amp; After Gallery</a>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <!-- Highlight Two -->
                            <div class="highlight-output highlight-2">
                                <img src="http://blueplasticsurgery.com/wp-content/themes/aaa-martinblue/mods/images/specialty/before-after.jpg" alt="before-after">
                                <span class="highlight-subtitle">Procedure: Facelift</span>
                                <span>Age: 45</span>
                                <span>Recovery: 2 Weeks</span>
                                <p>Details about what client wanted done and suggested procedure and why.</p>
                                <a href="#">Before &amp; After Gallery</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Left and right controls -->
                <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</div>
    @stop