@extends('layouts.master')

@section('content')
    <section class="row page_intro" style=" height: 230px;">
        <div class="row m0 inner-face" style=" padding-top: calc(7% - 10px);">
            <div class="container">
                <div class="row">
                    <h2> {{trans('main.breast')}} </h2>
                </div>
            </div>
        </div>
    </section>

    <section class="row contact_form_row">
        <div class="container">
            @foreach($breasts as $breast)
            <div class="row form-group">
                <div class="col-md-3">
                    <img src="{{ asset('public/uploads/large/' . $breast->media->guid) }}" class="img-thumbnail">
                </div>
                <div class="col-md-9">
                    <header class="entry-header">
                        <!-- The Post Title -->
                        <h2 class="entry-title"><a href="{{route('frontend.face.single.get',$breast->slug)}}" rel="bookmark" style="text-decoration:none">{{$breast->post_title}} </a></h2>
                    </header>
                    <div class="entry-summary">
             <p>{!! $breast->post_content !!}</p>
                    </div>
                </div>
            </div>
           @endforeach
        </div>
    </section>

 @include('partials.question')
    @stop