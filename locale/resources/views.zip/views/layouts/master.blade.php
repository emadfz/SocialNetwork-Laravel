@include('partials.header')
@yield('header')
@yield('content')
@include('partials.footer')
@yield('footer')



