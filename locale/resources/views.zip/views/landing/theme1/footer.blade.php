<div class="back-to-top"><i class="fa fa-angle-up fa-3x"></i></div>
<div class="pre-footer"></div>
<div style="display:none"><a href="www.creatova.com/ar">Creatova|كرياتوفا شركة تطوير الاعمال والتسويق اللكترونى</a></div>


<footer class="footer text-center" >©جميع الحقوق محفوظة لشركة اوركيدا</footer>    <!--[if lt IE 9]>
<script type="text/javascript" src="{{ asset('public/assets/landing/theme1/js/jquery-1.11.0.min.js?ver=1') }}"></script>
<![endif]-->
<!--[if (gte IE 9) | (!IE)]><!-->
<script type="text/javascript" src="{{ asset('public/assets/landing/theme1/js/jquery-2.1.0.min.js') }}"></script>
<!--<![endif]-->
<script type='text/javascript' src="{{ asset('public/assets/landing/theme1/js/underscore.min.js') }}"></script>
<script type='text/javascript' src="{{ asset('public/assets/landing/theme1/js/backbone.min.js') }}"></script>
<script type='text/javascript' src="{{ asset('public/assets/landing/theme1/js/bootstrap.min.js') }}"></script>
<script type='text/javascript' src="{{ asset('public/assets/landing/theme1/js/skrollr.min.js') }}"></script>
<script type='text/javascript' src="{{ asset('public/assets/landing/theme1/js/skrollr.decks.js') }}"></script>
<script type='text/javascript' src="http://maps.google.com/maps/api/js?sensor=false&#038;ver=0.1.4"></script>
<script type='text/javascript' src="{{ asset('public/assets/landing/theme1/js/toastr.min.js') }}"></script>
<script type='text/javascript' src="{{ asset('public/assets/landing/theme1/js/main.js') }}"></script>

<script type="text/javascript">
    (function(){
        "use strict";
        // Init global DOM elements, functions and arrays
        window.app             = {el : {}, fn : {}};
        app.el['loader']         = $('#loader');
        app.el['mask']           = $('#mask');


        //Preloader
        app.el['loader'].delay(700).fadeOut();
        app.el['mask'].delay(1200).fadeOut("slow");

    })();

</script>
</body>
</html>