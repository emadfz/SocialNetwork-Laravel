@section('header')
<?php
use App\Models\Post;

$faces = Post::where('post_type', 'face')->where('post_status', 'publish')->take('9')->get();
$burns = Post::where('post_type', 'burn')->where('post_status', 'publish')->take('9')->get();
$bodys = Post::where('post_type', 'body')->where('post_status', 'publish')->take('9')->get();
$breasts = Post::where('post_type', 'breast')->where('post_status', 'publish')->take('9')->get();
?>

        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>KINAWY CLINIC</title>
    <link rel="icon" href="{{asset('public/')}}/frontend/favicon/top.png">

    <!--Favicons-->
    <link rel="apple-touch-icon" sizes="57x57" href="{{asset('public')}}/frontend/favicon/apple-icon-57x57.html">
    <link rel="apple-touch-icon" sizes="60x60" href="{{asset('public')}}/frontend/favicon/apple-icon-60x60.html">
    <link rel="apple-touch-icon" sizes="72x72" href="{{asset('public')}}/frontend/favicon/apple-icon-72x72.html">
    <link rel="apple-touch-icon" sizes="76x76" href="{{asset('public')}}/frontend/favicon/apple-icon-76x76.html">
    <link rel="apple-touch-icon" sizes="114x114" href="{{asset('public')}}/frontend/favicon/apple-icon-114x114.html">
    <link rel="apple-touch-icon" sizes="120x120" href="{{asset('public')}}/frontend/favicon/apple-icon-120x120.html">
    <link rel="apple-touch-icon" sizes="144x144" href="{{asset('public')}}/frontend/favicon/apple-icon-144x144.html">
    <link rel="apple-touch-icon" sizes="152x152" href="{{asset('public')}}/frontend/favicon/apple-icon-152x152.html">
    <link rel="apple-touch-icon" sizes="180x180" href="{{asset('public')}}/frontend/favicon/apple-icon-180x180.html">
    <link rel="icon" type="image/png" sizes="192x192" href="{{asset('public')}}/frontend/favicon/android-icon-192x192.html">
    <link rel="icon" type="image/png" sizes="32x32" href="{{asset('public')}}/frontend/favicon/favicon-32x32.html">
    <link rel="icon" type="image/png" sizes="96x96" href="{{asset('public')}}/frontend/favicon/favicon-96x96.html">
    <link rel="icon" type="image/png" sizes="16x16" href="{{asset('public')}}/frontend/favicon/favicon-16x16.html">
    <link rel="manifest" href="{{asset('public')}}/frontend/favicon/manifest.html">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="{{asset('public')}}/frontend/favicon/ms-icon-144x144.html">
    <meta name="theme-color" content="#ffffff">

    <!--Bootstrap and Other Vendors-->

    <link rel="stylesheet" href="{{asset('public')}}/frontend/css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="{{asset('public')}}/frontend/css/font-awesome.min.css">
    <link rel="stylesheet" href="{{asset('public')}}/frontend/vendors/owl.carousel/css/owl.carousel.min.css">
    <link rel="stylesheet" href="{{asset('public')}}/frontend/vendors/owl.carousel/css/owl.theme.default.min.css">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/frontend/vendors/flexslider/flexslider.css" media="screen">
    <link rel="stylesheet" type="text/css" href="{{asset('public')}}/frontend/vendors/bootstrap-datepicker/css/datepicker3.css" media="screen">

    <!--Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Karla:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic' rel='stylesheet' type='text/css'>

    <!--Multi lang style sheets condition-->
    <?php $lang = LaravelLocalization::getCurrentLocale(); ?>
    @if( $lang == 'ar')
        <link rel="stylesheet" href="{{asset('public')}}/frontend/css/default/style_rtl.css">

    @else
    <link rel="stylesheet" href="{{asset('public')}}/frontend/css/default/style.css">
@endif
        <?php $lang = LaravelLocalization::getCurrentLocale(); ?>
        @if( $lang == 'ar')
    <link rel="stylesheet" href="{{asset('public')}}/frontend/css/bootstrap_rtl.min.css">
@else
        <link rel="stylesheet" href="{{asset('public')}}/frontend/css/bootstrap.min.css">
@endif
    <link rel="stylesheet" href="{{asset('public')}}/frontend/css/responsive/responsive.css">
    <!--[if lt IE 9]>

    <script src="http://8-digitalmarketing.com/demo/kenawy-clinic/global/frontend/js/html5shiv.min.js"></script>

    <script src="http://8-digitalmarketing.com/demo/kenawy-clinic/global/frontend/js/respond.min.js"></script>

    <![endif]-->
    <style>

    </style>
</head>
<body class="default about_page">
<section class="row top_bar">
    <div class="container">

    </div>
</section>

<nav class="navbar navbar-default navbar-fixed-top navbar2">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="home.html"><img src="{{asset('public')}}/frontend/images/logo/3.png" alt=""></a>
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main_nav" aria-expanded="false">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="book-appointment.html" class="navbar-toggle visible-xs" data-toggle="modal" data-target="#appointmefnt_form_pop">book appointment</a>
        </div>

        <div class="collapse navbar-collapse" id="main_nav">
            <ul class="nav navbar-nav navbar-right">
                <li class="dropdown">
                    <a href="{{route('frontend.home.get')}}" role="button">{{trans('main.home')}}</a>

                </li>
                <li class="dropdown">
                    <a href="{{route('frontend.face.get')}}" class="dropdown-toggle" data-toggle="" role="button" aria-expanded="false">{{trans('main.face')}}</a>
                    <ul class="dropdown-menu" role="menu">
@foreach($faces as $face)
                        <li><a href="{{route('frontend.face.single.get',$face->slug)}}">{{$face->post_title}}</a></li>
@endforeach

                    </ul>
                </li>
                <li class="dropdown">
                    <a href="{{route('frontend.breast.get')}}" class="dropdown-toggle" data-toggle="" role="button" aria-expanded="false">{{trans('main.breast')}}</a>
                    <ul class="dropdown-menu">
                        @foreach($breasts as $breast)
                            <li><a href="{{route('frontend.breast.single.get',$breast->slug)}}">{{$breast->post_title}}</a></li>
                        @endforeach

                    </ul>
                </li>

                <li class="dropdown">
                    <a href="{{route('frontend.body.get')}}" class="dropdown-toggle" data-toggle="" role="button" aria-expanded="false">{{trans('main.body')}}</a>
                    <ul class="dropdown-menu">
                        @foreach($bodys as $body)
                            <li><a href="{{route('frontend.body.single.get',$body->slug)}}">{{$body->post_title}}</a></li>
                        @endforeach

                    </ul>
                </li>
                <li class="dropdown">
                    <a href="{{route('frontend.burn.get')}}" class="dropdown-toggle" data-toggle="" role="button" aria-expanded="false">{{trans('main.burn')}}</a>
                    <ul class="dropdown-menu">
                        @foreach($burns as $burn)
                            <li><a href="{{route('frontend.burn.single.get',$burn->slug)}}">{{$burn->post_title}}</a></li>
                        @endforeach

                    </ul>
                </li>


                <li class="dropdown">
                    <a href="#" role="button">{{trans('main.blog')}}</a>

                </li>
                <li><a href="{{route('frontend.contact.get')}}">{{trans('main.contact')}}</a></li>
                <!-- Language Fix  -->
                <li>
                    <div class="lang-holder-link">
                        <!-- Collect the nav links, forms, and other content for toggling -->

                        <a href="../ar/home.html">عربى</a>
                    </div>
                </li>
                <!-- <li class="hidden-xs book"><a href="#" data-toggle="modal" data-target="#appointmefnt_form_pop">Book Appointment</a></li> -->

            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container -->
</nav>

@stop