@section('footer')
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="clearfix m0 footer_bottom">
                        <div class="heading fleft clearfix m0"><img src="{{asset('public')}}/frontend/images/logo/1.png"></div>
                        <ul class="list-inline social_menu m0 fleft">
                            <li><a href="https://www.facebook.com/Kenawyclinic"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://eg.linkedin.com/in/ahmed-kenawy-b6439459"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="https://www.instagram.com/dr_ahmedkenawy/"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3 footer_menuList">
                    <div class="clearfix menuList">
                        <ul class="firstOrderList nav">
                            <li class="active"><a href="home.html">{{trans('main.home')}}</a></li>
                            <li><a href="blog.html">{{trans('main.blog')}}</a></li>
                            <li><a href="contact.html">{{trans('main.contact')}}</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4 footer_address">
                    <div class="clearfix address m0">
                        <div class="media address_line">
                            <div class="media-left icon"><i class="fa fa-map-marker fa-fw"></i></div>
                            <div class="media-body address_text">{{trans('main.address')}}</div>
                        </div>
                        <div class="media address_line">
                            <div class="media-left icon"><i class="fa fa-envelope fa-fw"></i></div>
                            <div class="media-body address_text"><a href="mailto:d.ahmedkenawy@yahoo.com<">d.ahmedkenawy@yahoo.com</a></div>
                        </div>
                        <div class="media address_line">
                            <div class="media-left icon"><i class="fa fa-phone fa-fw"></i></div>
                            <div class="media-body address_text">0106261608 - 01001775586</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright copyright-holder"> Proudly made by &copy; <a href="http://www.8-digitalmarketing.com/" target="_blank">8 Digital Marketing 2016</a>.</div>
        </div>
    </footer>

    <div class="modal fade" id="appointmefnt_form_pop" tabindex="-1" role="dialog" aria-labelledby="appointmefnt_form_pop">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <form action="#" class="row m0 appointment_home_form2">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i class="fa fa-times-circle-o"></i>
                    </button>
                    <h2 class="title">BOOK<br>NOW</h2>
                    <div class="form_inputs row m0">
                        <div class="row m0 input_row">
                            <div class="col-sm-12 col-md-12 col-lg-6 p0">
                                <label for="app_fname">First Name</label>
                                <input type="text" class="form-control" id="app_fname" placeholder="Your First Name">
                            </div>
                            <div class="col-sm-12 col-md-12 col-lg-6 p0">
                                <label for="app_lname">Last Name</label>
                                <input type="text" class="form-control" id="app_lname" placeholder="Your Last Name">
                            </div>
                        </div>
                        <div class="row m0 input_row">
                            <label for="app_email">Email Address</label>
                            <input type="email" class="form-control" id="app_email" placeholder="Enter your Email Address">
                        </div>
                        <div class="row m0 input_row">
                            <label for="app_phone">Phone Number</label>
                            <input type="tel" class="form-control" id="app_phone" placeholder="Enter your Phone Number">
                        </div>
                        <div class="row m0 input_row">
                            <label for="app_date">Booking Date</label>
                            <div class="input-append date">
                                <input type="text" class="form-control" name="date" id="app_date" placeholder="Select the Appointment Date">
                                <span class="add-on"><i class="icon-th"></i></span>
                            </div>
                        </div>
                        <div class="row m0 input_row">
                            <label for="app_texts">Message</label>
                            <textarea id="app_texts" class="form-control" placeholder="Write down the Message"></textarea>
                        </div>
                        <input type="submit" class="form-control" value="book your appointment now">
                    </div>
                    <div class="row m0 form_footer">
                        <a href="#"><img src="{{asset('public')}}/frontend/images/call-now3.png" alt="">123 7890 456</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--jQuery-->
    <script src="{{asset('public')}}/frontend/js/jquery-2.1.3.min.js"></script>
    <!--Bootstrap JS-->
    <script src="{{asset('public')}}/frontend/js/bootstrap.min.js"></script>
    <!--Owl Carousel-->
    <script src="{{asset('public')}}/frontend/vendors/owl.carousel/js/owl.carousel.min.js"></script>
    <!--Counter Up-->
    <script src="{{asset('public')}}/frontend/vendors/counterup/jquery.counterup.min.js"></script>
    <!--Waypoints-->
    <script src="{{asset('public')}}/frontend/vendors/waypoints/waypoints.min.js"></script>
    <!--Bootstrap Date-->
    <script src="{{asset('public')}}/frontend/vendors/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <!--FlexSlider-->
    <script src="{{asset('public')}}/frontend/vendors/flexslider/jquery.flexslider-min.js"></script>
    <!--Strella JS-->
    <script src="{{asset('public')}}/frontend/js/theme.js"></script>
    </body>
    </html>
@stop